<div class='container'>
    <div class='row justify-content-center'>
        <div class='col text-center'>
            <h1><?=$mensaje?></h1>
            <a href='listado.php' class='btn btn-primary'>Volver al listado</a>
        </div>
    </div>
</div>